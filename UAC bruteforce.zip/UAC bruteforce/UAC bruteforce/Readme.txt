1. Run Setup.bat
2. Passlist.txt is for passwords that will be used
3. Run userbruteforce.bat